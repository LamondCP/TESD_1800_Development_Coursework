public class App {
    public static void main(String[] args) throws Exception {
        Triangle triangle = new Triangle();
        System.out.println(triangle);
        System.out.println("Area: " + triangle.getArea());
        System.out.println("Perimeter: " + triangle.getPerimeter());
    }
}
