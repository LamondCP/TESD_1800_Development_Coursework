import java.util.Scanner;

public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM!");
        System.out.println("Please enter your account ID: ");
        int accountId = scanner.nextInt();
        
        System.out.println("What would you like to do?");
        System.out.println("1. Checking account");
        System.out.println("2. Savings account");
        int choice = scanner.nextInt();
        if (choice == 1) {
            CheckingAccount checkingAccount = new CheckingAccount(accountId, 0);
            checkingAccount.setAnnualInterestRate(4.5);
            System.out.println("Would you like to check your balance (1), withdraw money (2), or deposit money (3)?");
            int subChoice = scanner.nextInt();
            if (subChoice == 1) {
                System.out.println("Checking balance: " + checkingAccount.getBalance());
            } else if (subChoice == 2) {
                System.out.println("Enter the amount you would like to withdraw:");
                double amount = scanner.nextDouble();
                checkingAccount.withdraw(amount);
                System.out.println("Withdrawal successful. New balance: " + checkingAccount.getBalance());
            } else if (subChoice == 3) {
                System.out.println("Enter the amount you would like to deposit:");
                double amount = scanner.nextDouble();
                checkingAccount.deposit(amount);
                System.out.println("Deposit successful. New balance: " + checkingAccount.getBalance());
            }
        } else if (choice == 2) {
            SavingsAccount savingsAccount = new SavingsAccount(accountId, 0);
            savingsAccount.setAnnualInterestRate(4.5);
            System.out.println( "Would you like to check your balance (1), withdraw money (2), or deposit money (3)?");
            int subChoice = scanner.nextInt();
            if (subChoice == 1) {
                System.out.println("Savings balance: " + savingsAccount.getBalance());
            } else if (subChoice == 2) {
                System.out.println("Enter the amount you would like to withdraw:");
                double amount = scanner.nextDouble();
                savingsAccount.withdraw(amount);
                System.out.println("Withdrawal successful. New balance: " + savingsAccount.getBalance());
            } else if (subChoice == 3) {
                System.out.println("Enter the amount you would like to deposit:");
                double amount = scanner.nextDouble();
                savingsAccount.deposit(amount);
                System.out.println("Deposit successful. New balance: " + savingsAccount.getBalance());
            }
        } else {
            System.out.println("Invalid choice.");
        }

        System.out.println("Is there anything else you would like to do? (1)yes (2)no");
        int continueChoice = scanner.nextInt();
        if (continueChoice == 1) {
            main(args);
        } else {
            System.out.println("Thank you for using the ATM. Goodbye!");
        }

        Account account = new Account(accountId, 0);
        account.setAnnualInterestRate(4.5);


}
}
