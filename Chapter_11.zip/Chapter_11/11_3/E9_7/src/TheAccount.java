import java.util.Date;

class Account {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;
    private double overdraftLimit;

    public Account() {
        this(0, 0);
    }

    public Account(int id, double balance) {
        this.id = id;
        this.balance = balance;
        this.annualInterestRate = 0;
        this.dateCreated = new Date();
        this.overdraftLimit = -1; // Set the overdraft limit to $-1 to indicate to set overdraft fee to $35 if the balance goes below $0. 
        // This is a temporary solution until I can figure out how to implement the overdraft fee properly.
    }

    public CheckingAccount createCheckingAccount() {
        return new CheckingAccount(this.id, this.balance);
    }
    public SavingsAccount createSavingsAccount() {
        return new SavingsAccount(this.id, this.balance);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public double getMonthlyInterestRate() {
        return annualInterestRate / 100 / 12;
    }

    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }
}

class CheckingAccount extends Account {
    public CheckingAccount(int id, double balance) {
        super(id, balance);
    }
}

class SavingsAccount extends Account {
    public SavingsAccount(int id, double balance) {
        super(id, balance);
    }
}